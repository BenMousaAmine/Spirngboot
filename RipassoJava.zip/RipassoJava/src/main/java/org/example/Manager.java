package org.example;

public class Manager extends Lavoratore{
    String area ;


    public Manager(String nome, String cognome, float stupendio , String area) {
        super(nome, cognome, stupendio);
        setArea(area);

    }
    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    @Override
    public String toString() {
        return "Manager{" +
                "area='" + area + '\'' +
                ", stupendio=" + stupendio +
                ", nome='" + nome + '\'' +
                ", cognome='" + cognome + '\'' +
                '}';
    }
}
