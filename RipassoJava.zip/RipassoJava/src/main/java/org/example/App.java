package org.example;

import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {

        Azienda a1 = new Azienda() ;
        Scanner scanner = new Scanner(System.in);

        int choice;
        do {
            System.out.println("Menu:");
            System.out.println("1. Stipendio Medio in Azienda");
            System.out.println("2. Stipendio Massimo in Azienda");
            System.out.println("3. Stipendio Minimo in Azienda");
            System.out.println("4. Dipendente che ha il massino stipendio");
            System.out.println("5. Dipendete che ha il mainimo stipendio");
            System.out.println("6. Numero di dipendete in Azienda");
            System.out.println("7. Numero di Manager in Azienda");
            System.out.println("8. Numero di lavoratore semplice in Azienda");
            System.out.println("9. Stipendio Medio di lavoratore semplice");
            System.out.println("10. Stipendio Massimo di lavoratore semplice");
            System.out.println("11. Stipendio Minimo di lavoratore semplice");
            System.out.println("12. Stipendio Medio di Manager");
            System.out.println("13. Stipendio Massimo di Manager");
            System.out.println("14. Stipendio Minimo di Manager");
            System.out.print("Scelta: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.println(a1.stupendioMedio());
                    break;
                case 2:
                    System.out.println(a1.MaxStipendio());
                    break;
                case 3:
                    System.out.println(a1.MinStpendio());
                    break;
                case 4:
                    System.out.println(a1.dipendenteMaxStipendio());
                    break;
                case 5:
                    System.out.println(a1.dipendenteMinStpendio());
                    break;
                case 6:
                    System.out.println(a1.dipendenti.size());
                    break;
                case 7:
                    System.out.println(a1.numManager());
                    break;
                case 8:
                    System.out.println(a1.numLavoratore());
                    break;
                case 9:
                    System.out.println(a1.stupendioMediolavoratoreSemplice());
                    break;
                case 10:
                    System.out.println(a1.stupendioMaxLavoratoreSemplice());
                    break;
                case 11:
                    System.out.println(a1.stpendioMinLavoratoreSemplice());
                    break;
                case 12:
                    System.out.println(a1.stupendioMedioManager());
                    break;
                case 13:
                    System.out.println(a1.stupendioMaxManger());
                    break;
                case 14:
                    System.out.println(a1.stpendioMinManager());
                    break;
                default:
                    System.out.println("Scelta non valida.");
                    break;
            }
        } while (choice != 14);

        scanner.close();
    }


}
