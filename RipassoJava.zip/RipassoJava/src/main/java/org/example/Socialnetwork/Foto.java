package org.example.Socialnetwork;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Locale;

public class Foto {
    private User utentePubblica ;
    private LocalDateTime dataPublicazione ;
    private String descrizione ;
    private ArrayList<Commento> commenti = new ArrayList<>();

    public Foto(String descrizione , User utentePubblica , LocalDateTime dataPublicazione  ) {
        this.descrizione= descrizione ;
        this.utentePubblica = utentePubblica ;
        this.dataPublicazione = dataPublicazione ;
    }

    public void addComment (Commento commento) {
        commenti.add(commento);
    }
}

