package org.example.Socialnetwork;

import java.time.LocalDateTime;

public class Commentatori extends User{
    private LocalDateTime dataCommento  ;
    public Commentatori(String nome) {
        super(nome);

    }
    public void commentaFoto (Foto foto ,String comment ){
        Commento commento = new Commento(LocalDateTime.now() ,comment , this);
         foto.addComment(commento) ;
    }

}
