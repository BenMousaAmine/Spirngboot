package org.example.Socialnetwork;

import java.time.LocalDateTime;


public class Commento {
    private LocalDateTime dataCommento  ;
    private String commento ;
    private User userCommenta ;


    public Commento(LocalDateTime dataCommento, String commento, User userCommenta) {
        this.commento = commento;
        this.userCommenta = userCommenta;
        this.dataCommento = dataCommento.now();
    }


    @Override
    public String toString() {
        return "Commento{" +
                "dataCommento=" + dataCommento +
                ", commento='" + commento + '\'' +
                ", userCommenta=" + userCommenta +
                '}';
    }
}
