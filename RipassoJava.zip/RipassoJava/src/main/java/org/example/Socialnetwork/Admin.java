package org.example.Socialnetwork;

import java.time.LocalDateTime;

public class Admin extends User {
    public Admin(String nome) {
        super(nome);
    }
    public Foto pubblicaFotot (String descrizione , LocalDateTime dataCommento ){
        Foto photo = new Foto(descrizione , this , dataCommento.now());
        return  photo ;
    }
    public void commentaFoto (Foto foto ,String comment ){
        Commento commento = new Commento(LocalDateTime.now() ,comment , this);
        foto.addComment(commento) ;
    }



}
