package org.example.Socialnetwork;

public class SimpleUser extends User {
    public SimpleUser(String nome) {
        super(nome);
    }
}
