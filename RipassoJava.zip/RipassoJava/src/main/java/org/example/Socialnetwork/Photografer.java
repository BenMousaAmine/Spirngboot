package org.example.Socialnetwork;

import java.time.LocalDateTime;

public class Photografer extends User{
    public Photografer(String nome) {
        super(nome);
    }
    public Foto pubblicaFotot (String descrizione , LocalDateTime dataCommento ){
        Foto photo = new Foto(descrizione , this , dataCommento.now());
        return  photo ;
    }

}
