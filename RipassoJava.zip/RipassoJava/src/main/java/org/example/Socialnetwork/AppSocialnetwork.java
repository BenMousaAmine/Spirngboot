package org.example.Socialnetwork;

public class AppSocialnetwork {
    public static void main( String[] args )
    {

    }
}
