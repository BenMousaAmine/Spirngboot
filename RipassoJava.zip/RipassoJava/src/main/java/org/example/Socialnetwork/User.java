package org.example.Socialnetwork;

import java.time.LocalDateTime;

public class User {
    private String nome ;
    private LocalDateTime dataIscrizione ;

    public User(String nome) {
        setNome(nome);
        setDataIscrizione(dataIscrizione) ;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public LocalDateTime getDataIscrizione() {
        return dataIscrizione;
    }

    public void setDataIscrizione(LocalDateTime dataIscrizione) {
        this.dataIscrizione = dataIscrizione.now();
    }
}
