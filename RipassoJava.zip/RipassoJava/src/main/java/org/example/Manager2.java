package org.example;

public class Manager2 extends Worker {

    String area ;

    public Manager2(String nome, String cogmone, float stupendio , String area) {
        super(nome, cogmone, stupendio);
        setArea(area);
    }
    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String toString() {
        return "Manager{" +
            "area='" + area + '\'' +
                    ", stupendio=" + stupendio +
                    ", nome='" + nome + '\'' +
                    ", cognome='" + cogmone + '\'' +
                    '}';
    }
}
