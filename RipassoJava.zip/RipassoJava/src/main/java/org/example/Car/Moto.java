package org.example.Car;

public class Moto extends Veicolo {
    private int numPosti ;

    public Moto(String nomeProprietario, String matricola ,int  numPosti) {
        super(nomeProprietario, matricola);
        setNumPosti(numPosti);
    }

    public int getNumPosti() {
        return numPosti;
    }

    public void setNumPosti(int numPosti) {
        if ((numPosti == 0)||(numPosti == 1)){
            this.numPosti = numPosti;
        }

    }

}
