package org.example.Car;

public abstract class Veicolo {
    private  String nomeProprietario ;
    private String matricola ;

    public Veicolo(String nomeProprietario, String matricola) {
        setMatricola(matricola);
        setNomeProprietario(nomeProprietario);
    }

    public String getNomeProprietario() {
        return nomeProprietario;
    }

    public void setNomeProprietario(String nomeProprietario) {
        this.nomeProprietario = nomeProprietario;
    }

    public String getMatricola() {
        return matricola;
    }

    public void setMatricola(String matricola) {
        this.matricola = matricola;
    }


}
