package org.example.Car;

import java.util.ArrayList;
import java.util.List;

public class Autosalone {
    List<Veicolo> Car = new ArrayList<>();

    public Autosalone() {
        this.Car.add(new Moto("Antonio", "CZ14", 2));
        this.Car.add(new Moto("Sofia", "CX12", 1));
        this.Car.add(new Camion("Felipo", "WW20", 4));
        this.Car.add(new Camion("Alessandro", "QA15", 6));
        this.Car.add(new Auto("Andrea", "GM11", "Suv"));
        this.Car.add(new Auto("Marco", "GK10", "Berlina"));
        this.Car.add(new Auto("Pipo", "FH11", "Station Wagen"));
    }

    int numVeicoli() {
        int somma = 0 ;
        for (Veicolo v : Car){
            somma++ ;
        }
        return somma ;
    }
    int numAuto() {
        int somma = 0;
        for (Veicolo v : Car) {
            if (v instanceof Auto) {
                somma++;
            }
        }
        return somma;
    }

    int numMoto() {
        int somma = 0;
        for (Veicolo v : Car) {
            if (v instanceof Moto) {
                somma++;
            }
        }
        return somma;
    }

    int numCamion() {
        int somma = 0;
        for (Veicolo v : Car) {
            if (v instanceof Camion) {
                somma++;
            }
        }
        return somma;
    }

    int numMotoMonoOBiposti(int numDaVerificare) {
        int somma = 0;
        for (Veicolo v : Car) {
            if (v instanceof Moto) {
                if (((Moto) v).getNumPosti() == numDaVerificare) {
                    somma++;

                }
            }
        }
        return somma;
    }

    int MaxAssiCamion() {
        int maxAssi = 0;
        for (Veicolo v : Car) {
            if (v instanceof Camion) {
                if (((Camion) v).getNumAssi() > maxAssi) {
                    maxAssi = ((Camion) v).getNumAssi();
                }
            }
        }
        return maxAssi;
    }
    Camion camionConMaxAssi() {
        int maxAssi = MaxAssiCamion();
        for (Veicolo v : Car) {
            if (v instanceof Camion) {
                if (((Camion) v).getNumAssi() == maxAssi) {
                    return  ((Camion) v);
                }
            }
        }
        return null;
    }
    String camionConMinAssi() {
        int minAssi = 0;
        String cMinAssi = "" ;
        for (Veicolo v : Car) {
            if (v instanceof Camion) {
                if (((Camion) v).getNumAssi() < minAssi) {
                    minAssi = ((Camion) v).getNumAssi();
                    cMinAssi = v.getNomeProprietario() + " " + v.getMatricola() +" " + minAssi ;
                }
            }
        }
        return cMinAssi;
    }

    int MinAssiCamion() {
        int minAssi = 0 ;
        for (Veicolo v : Car) {
            if (v instanceof Camion) {
                if (((Camion) v).getNumAssi() < minAssi) {
                    minAssi = ((Camion) v).getNumAssi();
                }
            }
        }
        return minAssi;
    }
    int numSuvOBerlina ( String tip){
        int numSuv = 0 ;
        for (Veicolo v: Car) {
            if (v instanceof Auto){
                String tipo = ((Auto) v).getTipo().toUpperCase();
                if (tipo.equals(tip.toUpperCase())) {
                    numSuv++;
                }
                }
            }
        return numSuv ;
        }



}
