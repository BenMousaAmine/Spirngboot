package org.example.Car;

public class Auto extends Veicolo {
    private String tipo ;

    public Auto(String nomeProprietario, String matricola , String tipo) {
        super(nomeProprietario, matricola);
        setTipo(tipo);
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
