package org.example.Car;

import java.util.Scanner;

public class App {
    public static void main( String[] args )
    {

        Autosalone a1 = new Autosalone() ;
        Scanner scanner = new Scanner(System.in);

        int choice;
        do {
            System.out.println("Menu:");
            System.out.println("1. Numero Veicoli Presenti");
            System.out.println("2. Numero auto Presenti");
            System.out.println("3. Numero Moto Presenti");
            System.out.println("4. Numero Camion Presenti");
            System.out.println("5. Numero Moto Monoposti Presenti");
            System.out.println("6. Numero Moto biposti Presenti");
            System.out.println("7. Massimo  numero Assi presnti di Camion");
            System.out.println("8. Minimo numero Assi presnti di Camion");
            System.out.println("9. Stipendio Medio di lavoratore semplice");
            System.out.println("10. Stipendio Massimo di lavoratore semplice");
            System.out.println("11. Numero Auto Suv Presenti");
            System.out.println("12. Numero Auto Berlina Presenti");
            System.out.println("0. Exit");
            System.out.print("Scelta: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 0 :
                    System.out.println("Exit");
                    break;
                case 1:
                    System.out.println(a1.numVeicoli());
                    break;
                case 2:
                    System.out.println(a1.numAuto());
                    break;
                case 3:
                    System.out.println(a1.numMoto());
                    break;
                case 4:
                    System.out.println(a1.numCamion());
                    break;
                case 5:
                    System.out.println(a1.numMotoMonoOBiposti(1));
                    break;
                case 6:
                    System.out.println(a1.numMotoMonoOBiposti(2));
                    break;
                case 7:
                    System.out.println(a1.MaxAssiCamion());
                    break;
                case 8:
                    System.out.println(a1.MinAssiCamion());
                    break;
                case 9:
                    System.out.println(a1.camionConMaxAssi());
                    break;
                case 10:
                    System.out.println(a1.camionConMinAssi());
                    break;
                case 11:
                    System.out.println(a1.numSuvOBerlina("Suv"));
                    break;
                case 12:
                    System.out.println(a1.numSuvOBerlina("Berlina"));
                    break;
                default:
                    System.out.println("Scelta non valida.");
                    break;
            }
        } while ((choice < 13) & (choice > 0 ) );

        scanner.close();
    }
    }

