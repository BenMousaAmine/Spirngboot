package org.example.Car;

public class Camion extends Veicolo {
    private int numAssi ;

    public Camion(String nomeProprietario, String matricola ,int numAssi) {
        super(nomeProprietario, matricola);
        setNumAssi(numAssi);
    }

    public int getNumAssi() {
        return numAssi;
    }

    public void setNumAssi(int numAssi) {
        if (numAssi>0){
            this.numAssi = numAssi;
        }
    }


}
