package org.example;

public interface Persona {
    public  void setNome ( String nome) ;
    public void  setCognome (String cognome) ;

    public String getNome () ;
    public String getCognome () ;

}
