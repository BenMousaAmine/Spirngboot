package org.example;

public  abstract class Humain {
    String nome ;
    String cogmone;

    public Humain(String nome , String cogmone) {
        setCogmone(cogmone);
        setNome(nome);
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCogmone() {
        return cogmone;
    }

    public void setCogmone(String cogmone) {
        this.cogmone = cogmone;
    }

    @Override
    public  abstract String toString() ;

}
