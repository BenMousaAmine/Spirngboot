package org.example;

public class Lavoratore extends PersonaImp{
    float stupendio ;
    public Lavoratore(String nome, String cognome , float stupendio) {
        super(nome, cognome);
        setStupendio(stupendio);

    }

    public float getStupendio() {
        return stupendio;
    }

    public void setStupendio(float stupendio) {
        this.stupendio = stupendio;
    }

    @Override
    public String toString() {
        return "Lavoratore{" +
                "stupendio=" + stupendio +
                ", nome='" + nome + '\'' +
                ", cognome='" + cognome + '\'' +
                '}';
    }
}
