package org.example;

public class PersonaImp  implements Persona{
    String nome ;
    String cognome ;
    float stupendio ;
    public PersonaImp (String nome , String  cognome) {
        setNome(nome);
        setCognome(cognome);
     }
    public void setNome(String nome) {
        this.nome = nome ;
    }

    public void setCognome(String  cognome) {
     this.cognome = cognome ;
    }

    public String getNome() {
        return this.nome;
    }

    public String getCognome() {
        return this.cognome ;

    }

    public float getStupendio() {
        return stupendio;
    }
}
