package org.example;

import java.util.ArrayList;
import java.util.List;

public class Azienda {
    List<PersonaImp> dipendenti = new ArrayList<>();

    public Azienda() {
        this.dipendenti.add(new Lavoratore("Jacck" , "Jonez" , 1500) );
        this.dipendenti.add(new Lavoratore("Antonio" , "Jonez" , 1200) );
        this.dipendenti.add(new Lavoratore("Marc" , "Jonez" , 1800) );
        this.dipendenti.add(new Manager("Gray" , "Jonez" , 2500 , "tech") );
        this.dipendenti.add(new Manager("Amilia" , "Jonez" , 2400 , "food") );
        this.dipendenti.add(new Manager("Sofia" , "Jonez" , 3500 , "Clothes") );
    }

    float MaxStipendio() {
        float maxStipendio = 0.0F;
        for (PersonaImp dip : dipendenti) {
            if (dip.getStupendio() > maxStipendio) {
                maxStipendio = dip.getStupendio();
            }
        }
        return maxStipendio ;
    }
    String dipendenteMaxStipendio () {
        float maxStipendio = 0.0F;
        String dipendenteMaxStipendio = "";

        for (PersonaImp dip : dipendenti) {
            if (dip.getStupendio() > maxStipendio) {
                maxStipendio = dip.getStupendio();
                dipendenteMaxStipendio = dip.getNome() + " " + dip.getCognome();
            }
        }
        return dipendenteMaxStipendio ;
    }
    float MinStpendio() {
        float minStipendio = Float.MAX_VALUE;
        for (PersonaImp dip : dipendenti) {
            if (dip.getStupendio() < minStipendio) {
                minStipendio = dip.getStupendio();
            }
        }
        return minStipendio;
    }

   String dipendenteMinStpendio() {
       float minStipendio = 0.0F;
       String dipendenteMinStipendio = "";

       for (PersonaImp dip : dipendenti) {
           if (dip.getStupendio() < minStipendio) {
               minStipendio = dip.getStupendio();
               dipendenteMinStipendio = dip.getNome() + " " + dip.getCognome();
           }
       }
       return dipendenteMinStipendio ;
   }
    float stupendioMedio () {
        float totale = 0 ;
        for (PersonaImp dip : dipendenti) {
            totale +=  dip.getStupendio() ;
        }
        return totale / numLavoratore();
    }
    int numManager () {
       int totManager = 0 ;
                 for (PersonaImp dip : dipendenti) {
                     if( dip instanceof Manager ){
                        totManager ++ ;
                     }
                 }
          return totManager ;
        }
    int numLavoratore(){
        int totLavoratore = 0 ;
        for (PersonaImp dip :dipendenti) {
            if(dip instanceof Lavoratore){
                totLavoratore ++ ;
            }
        }
        return totLavoratore;
    }

    float stupendioMedioManager () {
        float totale = 0;
        for (PersonaImp dip : dipendenti) {
            if (dip instanceof Manager) {
                totale += dip.getStupendio();
            }
        }
        return totale / numManager();
    }
    float stupendioMaxManger () {
        float maxStipendio = 0.0F;
        for (PersonaImp dip : dipendenti) {
            if (dip instanceof Manager) {
                if (dip.getStupendio() > maxStipendio) {
                    maxStipendio = dip.getStupendio();
                }
            }
        }
        return maxStipendio ;
    }
    float stpendioMinManager(){
        float minStipendio =  Float.MAX_VALUE;
        for (PersonaImp dip : dipendenti) {
            if (dip instanceof Manager) {
                if (dip.getStupendio() < minStipendio) {
                    minStipendio = dip.getStupendio();
                }
            }
        }
        return minStipendio ;
    }

    float stupendioMediolavoratoreSemplice () {
        float totale = Float.MAX_VALUE;
        for (PersonaImp dip : dipendenti) {
            if (!(dip instanceof Manager)) {
                totale += dip.getStupendio();
            }
        }
        return totale / (numLavoratore() - numManager());
    }

    float stupendioMaxLavoratoreSemplice () {
        float maxStipendio = 0.0F;
        for (PersonaImp dip : dipendenti) {
            if (!(dip instanceof Manager)) {
                if (dip.getStupendio() > maxStipendio) {
                    maxStipendio = dip.getStupendio();
                }
            }
        }
        return maxStipendio ;
    }
    float stpendioMinLavoratoreSemplice(){
        float minStipendio = 0.0F;
        for (PersonaImp dip : dipendenti) {
            if (!(dip instanceof Manager)) {
                if (dip.getStupendio() < minStipendio) {
                    minStipendio = dip.getStupendio();
                }
            }
        }
        return minStipendio ;
    }

}

