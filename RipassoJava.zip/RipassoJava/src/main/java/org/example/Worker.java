package org.example;

public class Worker extends Humain {
    float stupendio;

    public Worker(String nome, String cogmone , float stupendio) {
        super(nome, cogmone);
        setStupendio(stupendio);
    }

    public String toString() {
        return "Lavoratore{" +
                "stupendio=" + stupendio +
                ", nome='" + nome + '\'' +
                ", cognome='" + cogmone + '\'' +
                '}';
    }

    public float getStupendio() {
        return stupendio;
    }

    public void setStupendio(float stupendio) {
        this.stupendio = stupendio;
    }
}
