package com.example.prestiticountry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrestitiCountryApplicationTests {

	@Test
	void contextLoads() {
	}

}
