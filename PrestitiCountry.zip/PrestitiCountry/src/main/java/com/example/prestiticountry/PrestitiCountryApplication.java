package com.example.prestiticountry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrestitiCountryApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrestitiCountryApplication.class, args);
	}

}
