package com.example.prestiticountry.repository;

import com.example.prestiticountry.domain.Prestito;
import org.springframework.data.repository.CrudRepository;

public interface PrestitoRepository extends CrudRepository<Prestito, Long> {
}
